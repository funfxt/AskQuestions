

-- Admin Database Script
------------------------------------------------------------------
-- In this section user can ask any questions   
-----------------------------------------------------------------
 create table Create_Post
   (
     Id bigint Identity(1,1) Primary Key,
	 Question nvarchar(max) not null,
	 [Description]    nvarchar(max) not null,
	 CreateDate  DateTime default getdate() not null,
	 Category bigint   foreign key references Post_Category(id),
	 Tags     nvarchar(max),
	 IsActive  bit
	 )
------------------------------------------------------------------
-- In This Section Post Image are save if user select any picture
------------------------------------------------------------------
Create table Post_Image
(
id bigint identity(1,1),
ImageURL  nvarchar(max),
Post_Id  bigint foreign key references Create_Post(id),
IsActive bit
)
---------------------------------------------------------------------
-- In This Section Post category are saved
---------------------------------------------------------------------
	Create table Post_Category
(
id bigint identity(1,1) primary key,
Category_Name  varchar(100),
Tags           varchar(max),
IsActive       bit,
)

------------------------------------------------------------------------
-- Answer Section
------------------------------------------------------------------------
    create table Post_Answer
    (
      Id bigint Identity(1,1) Primary Key,
	  Answer nvarchar(max) not null,
      CreateDate  DateTime default getdate() not null,
	  Qid bigint   foreign key references Create_Post(id),
	  IsActive  bit
	 )
-------------------------------------------------------------------------
-- Reply Answer
-------------------------------------------------------------------------
  create table Answer_Reply
    (
      Id bigint Identity(1,1) Primary Key,
	  Reply nvarchar(max) not null,
      CreateDate  DateTime default getdate() not null,
	  IsActive  bit ,
	  Ans_reply bigint   foreign key references Post_Answer(id),
	  Reply_id  bigint DEFAULT 0 not null
	 )
---------------------------------------------------------------------------
-- This Section  is for total action on  any posts.
---------------------------------------------------------------------------
create table Total_Actions
(
id bigint identity(1,1),
Likes bigint,
Replies bigint,
Upvote  bigint,
Downvotes bigint,
Question_Id bigint foreign key references Create_Post(Id)
)